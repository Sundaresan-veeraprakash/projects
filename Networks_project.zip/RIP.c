#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//routing table contains array of networkid(host),next router , hop count;
//len - total number of networks in that router;
struct router_table
{
	char **netid;
	int len;
	char **next;
	int *hop_count;
};
//to compute adjacency matrix
//edge - if common networkid(host) exists between two routers
int **adj_mat(int num_routers,struct router_table *r1,int **graph)
{
	int i,j,k,t;
	for(i=0;i<num_routers-1;i++)
	{
		for(j=0;j<r1[i].len;j++)
		{
			for(k=i+1;k<num_routers;k++)
			{
				for(t=0;t<r1[k].len;t++)
				{
					if(strcmp(r1[i].netid[j],r1[k].netid[t])==0)
					{
						graph[i][k]=1;
						//graph[k][i]=1;
						break;
					}
				}
			}
		}
	}
	return graph;
}
//check whether the specific network exists in the neighboring router's table
int check(char *res,char **netid,int len1)
{
	int i=0;
	while(i<len1)
	{
		if(strcmp(res,netid[i])==0)
		{
			return i;
		}
		i+=1;
	}
	return -1;
}

void update_neighbor(int **graph,int num_routers,int num_host,struct router_table *r1)
{
	int i,j,k;
	
	for(i=0;i<num_routers;i++)
	{
		for(k=0;k<num_routers;k++)
		{
			if(graph[i][k]==1)
			{
				printf("graph-%d\n",k);
				int t=r1[k].len;
				for(j=0;j<r1[i].len;j++)
				{
					//check whether r1's specific network present in r2's network 
					//if not then update the r2's table by appending the r1's specific network
					if(check(r1[i].netid[j],r1[k].netid,r1[k].len)==-1)
					{
						r1[k].netid[t]=r1[i].netid[j];
						//strcpy(r1[i+1].netid[t],r1[i].netid[j]);
						//printf("%s",r1[i+1].netid[t]);
						char *str;
						char *str1;
						str1=(char *)malloc(5*sizeof(char));
						str=(char *)malloc(5*sizeof(char));
						strcpy(str1,"R");
						//printf("%d\n",i);
						sprintf(str,"%d",i+1);
						strcat(str1,str);
						r1[k].next[t]=str1;
						//strcpy(r1[i+1].next[t],"R");
						r1[k].hop_count[t]=r1[i].hop_count[j]+1;
						r1[k].len+=1;
						//printf("%s\n",r1[k].netid[t]);
						t+=1;
					}
				}
			}
		}
	}
	i=0;
	k=0;
	j=0;
	for(i=num_routers-1;i>=0;i--)
	{
		for(k=num_routers-1;k>=0;k--)
		{
			if(graph[i][k]==1)
			{
				printf("graph-%d\n",k);
				int t=r1[i].len;
				for(j=0;j<r1[k].len;j++)
				{
					//check whether r1's specific network present in r2's network 
					//if not then update the r2's table by appending the r1's specific network
					if(check(r1[k].netid[j],r1[i].netid,r1[i].len)==-1)
					{
						r1[i].netid[t]=r1[k].netid[j];
						//strcpy(r1[i+1].netid[t],r1[i].netid[j]);
						//printf("%s",r1[i+1].netid[t]);
						char *str;
						char *str1;
						str1=(char *)malloc(5*sizeof(char));
						str=(char *)malloc(5*sizeof(char));
						strcpy(str1,"R");
						printf("%d\n",i);
						sprintf(str,"%d",k+1);
						strcat(str1,str);
						r1[i].next[t]=str1;
						//strcpy(r1[i+1].next[t],"R");
						r1[i].hop_count[t]=r1[k].hop_count[j]+1;
						r1[i].len+=1;
						printf("%s\n",r1[i].netid[t]);
						t+=1;
					}
					else
					{
						int pos=check(r1[k].netid[j],r1[i].netid,r1[i].len);
						if(r1[k].hop_count[j]<r1[i].hop_count[pos])
						{
							r1[i].hop_count[pos]=r1[k].hop_count[j]+1;
							char *str;
							char *str1;
							str1=(char *)malloc(5*sizeof(char));
							str=(char *)malloc(5*sizeof(char));
							strcpy(str1,"R");
							printf("%d\n",i);
							sprintf(str,"%d",k+1);
							strcat(str1,str);
							r1[i].next[pos]=str1;
						}
					}
				}
			}
		}
	}
	
	for(i=0;i<num_routers;i++)
	{
		printf("router %d:\n",i+1);
		for(j=0;j<r1[i].len;j++)
		{
			printf("%s-",r1[i].netid[j]);
			printf("%s-",r1[i].next[j]);
			printf("%d",r1[i].hop_count[j]);
			printf("\n");
			
		}
		printf("\n");
	}
}


void main()
{
	int num_routers;
	printf("enter the number of routers:");
	scanf("%d",&num_routers);
	struct router_table r1[num_routers];
	int i,j;
	int num_host=0;
	for(i=0;i<num_routers;i++)
	{
		printf("enter the host that are connected are router %d:",i+1);
		scanf("%d",&r1[i].len);
		num_host+=r1[i].len;
		r1[i].netid=(char **)malloc(10*sizeof(char *));
		r1[i].next=(char **)malloc(10*sizeof(char *));
		r1[i].hop_count=(int *)malloc(10*sizeof(int));
		for(j=0;j<r1[i].len;j++)
		{
			r1[i].netid[j]=(char *)malloc(10*sizeof(char));
			r1[i].next[j]=(char *)malloc(10*sizeof(char));
			scanf("%s",r1[i].netid[j]);
			strcpy(r1[i].next[j],"NULL");
			r1[i].hop_count[j]=1;
			
		}	
	}
	
	
	
	for(i=0;i<num_routers;i++)
	{
		printf("router %d:\n",i+1);
		for(j=0;j<r1[i].len;j++)
		{
			printf("%s-",r1[i].netid[j]);
			printf("%s-",r1[i].next[j]);
			printf("%d",r1[i].hop_count[j]);
			printf("\n");
			
		}
		printf("\n");
	}
	int **graph;
	graph=(int **)malloc(num_routers*sizeof(int *));
	for(i=0;i<num_routers;i++)
	{
		graph[i]=(int *)malloc(num_routers*sizeof(int));
		for(j=0;j<num_routers;j++)
		{
			graph[i][j]=0;
		}
	}
	graph=adj_mat(num_routers,r1,graph);
	for(i=0;i<num_routers;i++)
	{
		for(j=0;j<num_routers;j++)
		{
			printf("%d\t",graph[i][j]);
		}
		printf("\n");
	}
	update_neighbor(graph,num_routers,num_host,r1);
}
