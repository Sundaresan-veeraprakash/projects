import clinic.*;
import java.util.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.lang.Exception;
class Main
{
    public static void main(String[] args) 
    {
        
        Scanner s=new Scanner(System.in);
        String details[]=new String[7];
        int patient_id=0;
        int doctor_type=0;
        int date=0;
        System.out.println("enter 1:doctor\tenter 2:patient\tenter 3:admin:");
        int  decider=s.nextInt();
        if(decider==2)
        {
            Patient p=new Patient(details,patient_id,decider,doctor_type,date);
        }
        else if(decider==1)
        {
            Doctor d=new Doctor(details,patient_id,decider,doctor_type,date);
        }
        else if(decider==3)
        {
            Admin a=new Admin(details,patient_id,decider,doctor_type,date);
        }
        /*try
        {
            List<String> listOfStrings
            = new ArrayList<String>();
            Scanner sc = new Scanner(new FileReader("general.txt")).useDelimiter(",\\s*");
            String str;
            while (sc.hasNext()) 
            {
                str = sc.next();
                listOfStrings.add(str);
            }
            String[] array= listOfStrings.toArray(new String[0]);
            for (String eachString : array) 
            {
                System.out.println(eachString);
            }
        } 
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }*/
    }
}
