package clinic;
import java.util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileNotFoundException;
public class Doctor extends Patient
{
    String doctor_name,doctor_cat;
    Queue<String>[] q1=new Queue[31];
    Queue<Integer>[] q2=new Queue[31];
    public static java.io.File f1;
    public static java.io.FileWriter myWriter1;
    public static java.io.File f2;
    public static java.io.FileWriter myWriter2;
    Scanner s2=new Scanner(System.in);
    public Doctor(String[] details,int patient_id,int decider,int doctor_type,int date)
    {
        super(details,patient_id,decider,doctor_type,date);
        System.out.println("doctor name:");
        doctor_name=s2.next();
        System.out.println("category:");
        doctor_cat=s2.next();
        System.out.println("enter 1 to view today's appointment list\n2 to view patient's history:");
        int decider4=s2.nextInt();
        if(decider4==1)
        {
            this.appointment_list(doctor_cat);
        }
        if(decider4==2)
        {
            this.view_history();
        }
    }
    void appointment_list(String cat)
    {
        if(cat.equals("general")==true)
        {
            try
            {
                List<String> listOfStrings= new ArrayList<String>();
                Scanner sc = new Scanner(new FileReader("general.txt")).useDelimiter(",\\s*");
                String str;
                while (sc.hasNext()) 
                {
                    str = sc.next();
                    listOfStrings.add(str);
                }
                String[] array= listOfStrings.toArray(new String[0]);
                for(int j=0;j<30;j++)
                {
                    q1[j]=new LinkedList<String>();
                }
                Calendar calendar = Calendar.getInstance();
                int cal=(calendar.get(Calendar.DAY_OF_MONTH));
                for (int i=0;i<listOfStrings.size();i++) 
                {
                    if(array[i].equals(String.valueOf(cal))==true)
                    {
                        q1[cal].offer(array[i+1]);
                        //System.out.println("pos"+array[i+1]);
                    }
                    else if(Integer.parseInt(array[i])<=31)
                    {
                        q1[Integer.parseInt(array[i])].offer(array[i+1]);
                    }
                    //System.out.println(eachString);
                }
                System.out.println(cal+"-appointment list");
                int check=0;
                for(String elem:q1[cal])
                {
                    if(elem==null)
                    {
                        continue;
                    }
                    else
                    {
                        check++;
                        System.out.println(elem+"\n");
                    }
                }
                if(check==0)
                {
                    System.out.println("no appointements");
                }
                System.out.println("Enter 1 if you want to see this whole month's appointment list\n 2 for consult patients:");
                int decider5=s2.nextInt();
                if(decider5==1)
                {
                for(int j=0;j<30;j++)
                {
                    if(q1[j].isEmpty()==true)
                    {
                        continue;
                    }
                    else
                    {
                        System.out.println(j+"-appointment list");
                        for(String elem:q1[j])
                        {
                            System.out.println(elem+"\n");
                        }
                    }
                }
                }
                if(decider5==2)
                {
                    this.consult(cat);
                }
            } 
            catch (FileNotFoundException e)
            {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
        if(cat.equals("eye")==true)
        {
            try
            {
                List<String> listOfStrings= new ArrayList<String>();
                Scanner sc = new Scanner(new FileReader("eye.txt")).useDelimiter(",\\s*");
                String str;
                while (sc.hasNext()) 
                {
                    str = sc.next();
                    listOfStrings.add(str);
                }
                String[] array= listOfStrings.toArray(new String[0]);
                for(int j=0;j<30;j++)
                {
                    q1[j]=new LinkedList<String>();
                }
                Calendar calendar = Calendar.getInstance();
                int cal=(calendar.get(Calendar.DAY_OF_MONTH));
                for (int i=0;i<listOfStrings.size();i++) 
                {
                    if(array[i].equals(String.valueOf(cal))==true)
                    {
                        q1[cal].offer(array[i+1]);
                        //System.out.println("pos"+array[i+1]);
                    }
                    else if(Integer.parseInt(array[i])<=31)
                    {
                        q1[Integer.parseInt(array[i])].offer(array[i+1]);
                    }
                    //System.out.println(eachString);
                }
                System.out.println(cal+"-appointment list");
                int check=0;
                for(String elem:q1[cal])
                {
                    if(elem==null)
                    {
                        continue;
                    }
                    else
                    {
                        check++;
                        System.out.println(elem+"\n");
                    }
                }
                if(check==0)
                {
                    System.out.println("no appointements");
                }
                System.out.println("Enter 1 if you want to see this whole month's appointment list\n 2 for consult patients:");
                int decider5=s2.nextInt();
                if(decider5==1)
                {
                for(int j=0;j<30;j++)
                {
                    if(q1[j].isEmpty()==true)
                    {
                        continue;
                    }
                    else
                    {
                        System.out.println(j+"-appointment list");
                        for(String elem:q1[j])
                        {
                            System.out.println(elem+"\n");
                        }
                    }
                }
                }
                if(decider5==2)
                {
                    this.consult(cat);
                }
            } 
            catch (FileNotFoundException e)
            {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
        if(cat.equals("ENT")==true)
        {
            try
            {
                List<String> listOfStrings= new ArrayList<String>();
                Scanner sc = new Scanner(new FileReader("ENT.txt")).useDelimiter(",\\s*");
                String str;
                while (sc.hasNext()) 
                {
                    str = sc.next();
                    listOfStrings.add(str);
                }
                String[] array= listOfStrings.toArray(new String[0]);
                for(int j=0;j<30;j++)
                {
                    q1[j]=new LinkedList<String>();
                }
                Calendar calendar = Calendar.getInstance();
                int cal=(calendar.get(Calendar.DAY_OF_MONTH));
                for (int i=0;i<listOfStrings.size();i++) 
                {
                    if(array[i].equals(String.valueOf(cal))==true)
                    {
                        q1[cal].offer(array[i+1]);
                        //System.out.println("pos"+array[i+1]);
                    }
                    else if(Integer.parseInt(array[i])<=31)
                    {
                        q1[Integer.parseInt(array[i])].offer(array[i+1]);
                    }
                    //System.out.println(eachString);
                }
                System.out.println(cal+"-appointment list");
                for(String elem:q1[cal])
                {
                    System.out.println(elem+"\n");
                }
                System.out.println("Enter 1 if you want to see this whole month's appointment list\n 2 for consult patients:");
                int decider5=s2.nextInt();
                if(decider5==1)
                {
                for(int j=0;j<30;j++)
                {
                    if(q1[j].isEmpty()==true)
                    {
                        continue;
                    }
                    else
                    {
                        System.out.println(j+"-appointment list");
                        for(String elem:q1[j])
                        {
                            System.out.println(elem+"\n");
                        }
                    }
                }
                }
                if(decider5==2)
                {
                    this.consult(cat);
                }
            } 
            catch (FileNotFoundException e)
            {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }
    void consult(String cat)
    {
        int decider6;
        String filename1;
        int w=0;
        if(cat.equals("general")==true)
        {
            Calendar calendar = Calendar.getInstance();
            int date1=(calendar.get(Calendar.DAY_OF_MONTH));
            for(String elem:q1[date1])
            {
                System.out.println(elem+"\n");
                System.out.println("enter 0 to skip this patient:");
                int decider9=s2.nextInt();
                if(decider9==0)
                {
                    continue;
                }
                //System.out.println(elem+"\n");
                filename1=elem+".txt";
                //System.out.println(filename1);
                System.out.println("write the prescription:");
                try
                {
                    f1=new File(filename1);
                    myWriter1 = new FileWriter(filename1,true);
                    myWriter1.write("\n"+date1+"-");
                    String dummy=s2.nextLine();
                    String pres=s2.nextLine();
                    myWriter1.write(pres);
                    myWriter1.close();
                    System.out.println("enter 1 to take lab tests:");
                    int decider7=s2.nextInt();
                    if(decider7==1)
                    {
                        this.lab_test(elem);
                    }
                }
                catch(Exception e)
                {
                    System.out.println("cannot write");
                }
                System.out.println("enter 1 to consult next patient:");
                decider6=s2.nextInt();
                if(decider6!=1)
                {
                    w++;
                    break;
                }  
            }
            if(w==0)
            {
                System.out.println("no more appointments");
            }
        }
        if(cat.equals("eye")==true)
        {
            Calendar calendar = Calendar.getInstance();
            int date1=(calendar.get(Calendar.DAY_OF_MONTH));
            for(String elem:q1[date1])
            {
                System.out.println("enter 0 to skip this patient:");
                int decider9=s2.nextInt();
                if(decider9==0)
                {
                    continue;
                }
                System.out.println(elem+"\n");
                filename1=elem+".txt";
                System.out.println(filename1);
                System.out.println("write the prescription:");
                try
                {
                    f1=new File(filename1);
                    myWriter1 = new FileWriter(filename1,true);
                    myWriter1.write("\n"+date1+"-");
                    String dummy=s2.nextLine();
                    String pres=s2.nextLine();
                    myWriter1.write(pres);
                    myWriter1.close();
                    System.out.println("enter 1 to take lab tests:");
                    int decider7=s2.nextInt();
                    if(decider7==1)
                    {
                        this.lab_test(elem);
                    }
                }
                catch(Exception e)
                {
                    System.out.println("cannot write");
                }
                System.out.println("enter 1 to consult next patient:");
                decider6=s2.nextInt();
                if(decider6!=1)
                {
                    break;
                }
            }
        }
        if(cat.equals("ENT")==true)
        {
            Calendar calendar = Calendar.getInstance();
            int date1=(calendar.get(Calendar.DAY_OF_MONTH));
            for(String elem:q1[date1])
            {
                System.out.println("enter 0 to skip this patient:");
                int decider9=s2.nextInt();
                if(decider9==0)
                {
                    continue;
                }
                System.out.println(elem+"\n");
                filename1=elem+".txt";
                System.out.println(filename1);
                System.out.println("write the prescription:");
                try
                {
                    f1=new File(filename1);
                    myWriter1 = new FileWriter(filename1,true);
                    myWriter1.write("\n"+date1+"-");
                    String dummy=s2.nextLine();
                    String pres=s2.nextLine();
                    myWriter1.write(pres);
                    myWriter1.close();
                    System.out.println("enter 1 to take lab tests:");
                    int decider7=s2.nextInt();
                    if(decider7==1)
                    {
                        this.lab_test(elem);
                    }
                }
                catch(Exception e)
                {
                    System.out.println("cannot write");
                }
                System.out.println("enter 1 to consult next patient:");
                decider6=s2.nextInt();
                if(decider6!=1)
                {
                    break;
                }
            }
        }
    }
    void view_history()
    {
        System.out.println("enter the patient_id you want to view:");
        String p_id=s2.next();
        String filename2=p_id+".txt";
        try
        {
            Scanner sc1 = new Scanner(new FileReader(filename2)).useDelimiter(",\\s*");
            String str;
            while(sc1.hasNext())
            {
                str=sc1.next();
                System.out.println(str);
            }
        }
        catch(Exception e)
        {
            System.out.println("cannot write");
        }
    }    
    void lab_test(String p_id1)
    {
        String filename3;
        filename3=p_id1+".txt";
        try
        {
            f1=new File("lab.txt");
            myWriter1 = new FileWriter("lab.test",true);
            myWriter1.write(p_id1+":");
            String dummy=s2.nextLine();
            String lab_details=s2.nextLine();
            myWriter1.write(lab_details+"\n");
            myWriter1.close();
            f2=new File(filename3);
            myWriter2=new FileWriter(filename3,true);
            myWriter2.write("lab:"+lab_details);
            myWriter2.close();
        }
        catch(Exception e)
        {
            System.out.println("cannot write");
        }
    }  
}