package clinic;
import java.util.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileNotFoundException;
public class Admin extends Patient
{
    public static java.io.File f;
    public static java.io.FileWriter myWriter;
    Queue<String>[] q1=new Queue[31];
    Scanner s3=new Scanner(System.in);
    public Admin(String[] details,int patient_id,int decider,int doctor_type,int date)
    {
        super(details,patient_id,decider,doctor_type,date);
        System.out.println("enter 1 to view patient list of a particular doctor\nenter 2 to info patients:");
        int decider10=s3.nextInt();
        if(decider10==1)
        {
            System.out.println("enter the category:");
            String cate=s3.next();
            this.p_list(cate);
        }
        else if(decider10==2)
        {
            System.out.println("write the information:");
            String dummy=s3.nextLine();
            String info=s3.nextLine();
            try
            {
                f = new File("info.txt");
                myWriter = new FileWriter("info.txt");
                myWriter.write(info);
                myWriter.close();
            }
            catch(Exception e)
            {
                System.out.println("cannot write");
            }
        }
    }
    void p_list(String cate)
    {
        String filename=cate+".txt";
        try
            {
                List<String> listOfStrings= new ArrayList<String>();
                Scanner sc = new Scanner(new FileReader(filename)).useDelimiter(",\\s*");
                String str;
                while (sc.hasNext()) 
                {
                    str = sc.next();
                    listOfStrings.add(str);
                }
                String[] array= listOfStrings.toArray(new String[0]);
                for(int j=0;j<30;j++)
                {
                    q1[j]=new LinkedList<String>();
                }
                Calendar calendar = Calendar.getInstance();
                int cal=(calendar.get(Calendar.DAY_OF_MONTH));
                for (int i=0;i<listOfStrings.size();i++) 
                {
                    if(array[i].equals(String.valueOf(cal))==true)
                    {
                        q1[cal].offer(array[i+1]);
                        //System.out.println("pos"+array[i+1]);
                    }
                    else if(Integer.parseInt(array[i])<=31)
                    {
                        q1[Integer.parseInt(array[i])].offer(array[i+1]);
                    }
                    //System.out.println(eachString);
                }
                System.out.println(cal+"-appointment list");
                int k=0;
                for(String elem:q1[cal])
                {
                    if(elem==null)
                    {
                        continue;
                    }
                    else
                    {
                        k++;
                        System.out.println(elem+"\n");
                    }
                }
                if(k==0)
                {
                    System.out.println("no appointments today");
                }
            }
            catch (FileNotFoundException e)
            {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
}