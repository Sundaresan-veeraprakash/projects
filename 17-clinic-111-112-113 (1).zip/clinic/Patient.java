package clinic;
import java.util.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.Exception;
import java.io.FileReader;
import java.io.File;
import java.io.FileNotFoundException;
public class Patient
{
    public int patient_id;
    public String[]details;
    static int k,z,t,z1,z2;
    public int decider;
    public int doctor_type;
    public int date;
    String filename;
    String str;
    public static java.io.File f;
    public static java.io.FileWriter myWriter;
   // patient_id[0]=100;
    //details[0][0]="sundar";details[0][1]="19";details[0][2]="male";details[0][3]="9585";details[0][4]="ddfdf fdfgd";details[0][5]="cold";details[0][6]="O+";
    Scanner s1=new Scanner(System.in);
    public Patient(String[] details,int patient_id,int decider,int doctor_type,int date)
    {
        this.patient_id=patient_id;
        this.details=details;
        this.decider=decider;
        //this.doctor_type=doctor_type;
        this.date=date;
        try
        {
        Scanner sc = new Scanner(new FileReader("info.txt")).useDelimiter(",\\s*");
        String str;
        while (sc.hasNext()) 
        {
          str = sc.next();
          System.out.print(str);
        }
        System.out.print("\n");
        }
        catch (FileNotFoundException e)
        {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }
       // patient_id=0;
       // details[0]="sundar";details[1]="19";details[2]="male";details[3]="9585";details[4]="ddfdf fdfgd";details[5]="cold";details[6]="O+";
        if(decider==2)
        { 
            this.decide();
        }
    }
    void decide()
    {
        System.out.println("enter 1:existing patient\tenter 2:new patient:");
        int decider1=s1.nextInt();
        if(decider1==2)
        {
          try
          {
            this.create(details,patient_id);
          }
          catch(InvalidNumberException e)
          {

          }
        }
        else
        {
            System.out.println("patient id:");
            this.patient_id=s1.nextInt();
            filename=String.valueOf(this.patient_id)+".txt";
            this.search(filename);
        }
    }
    public void create(String[]details,int patient_id)throws InvalidNumberException
    {
        System.out.println("enter patient details:");
         try
        {
          Scanner sc = new Scanner(new FileReader("id.txt")).useDelimiter(",\\s*");
          while (sc.hasNext()) 
          {
            str = sc.next();
            //patient_id=Integer.parseInt(str);
          }
          System.out.print("\n");
        }
        catch (FileNotFoundException e)
        {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }
        patient_id=Integer.parseInt(str)+1;
        try
        {
        f=new File("id.txt");
        myWriter=new FileWriter("id.txt");
        myWriter.write(String.valueOf(patient_id)+",");
        myWriter.close();
        }
        catch (IOException e)
        {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }
        try
        {
          System.out.println("patient name:");
          details[0]=s1.next();
          System.out.println("patient age:");
          int age=s1.nextInt();
          details[1]=String.valueOf(age);
          System.out.println("gender:");
          details[2]=s1.next();
        }
        catch(InputMismatchException e)
        {
          System.out.println(e);
        }
        System.out.println("phone number:");
        details[3]=s1.next();
        if(details[3].length()!=10)
        {
          throw new InvalidNumberException("invalid mobile number");
          //System.out.println("invalid number");
        }
        else
        {
          System.out.println("address:");
          String dummy=s1.nextLine();
          details[4]=s1.nextLine();
          System.out.println("health issues:");
          details[5]=s1.nextLine();
          System.out.println("blood group:");
          details[6]=s1.next();
          this.create_file(patient_id);
          this.doctor_decision(patient_id);
        }
    }
    void create_file(int n)
    {
      filename=String.valueOf(n)+".txt";
      try
      {
        f = new File(filename);
        if (f.createNewFile())
        {
          System.out.println("your id="+n);
        } 
        else 
        {
          System.out.println("File already exists.");
        }
        myWriter = new FileWriter(filename);
        for(int i=0;i<7;i++)
        {
          myWriter.write(this.details[i]+",");
        }
        myWriter.close();
      }
      catch (IOException e)
      {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }
    }
    void search(String filename)
    {
      File directoryPath = new File("C:/Users/se986/OneDrive/Desktop/project2");
      String contents[] = directoryPath.list();
      for(int i=0; i<contents.length; i++) 
      {
        if(contents[i].equals(filename))
        {
          System.out.println("found");
        }
      }
      System.out.println("enter 1 to appointment\nenter 2 to view recent details:");
      int decider8=s1.nextInt();
      if(decider8==1)
      {
        this.doctor_decision(patient_id);
      }
      else if(decider8==2)
      {
        this.recents(filename);
      }
      /* try
       {

        BufferedWriter b=new BufferedWriter(new FileWriter(filename));
        PrintWriter out = new PrintWriter(new FileWriter(filename));
        myWriter = new FileWriter(filename);
        out.print("100");
        out.print("200");
        out.close();
        f = new File(filename);
        myWriter = new FileWriter(filename,true);
        myWriter.write("sundar");
        myWriter.close();
       }
       catch(Exception e)
       {
        System.out.println("cannot write");
       }*/
      }
      void doctor_decision(int patient_id)
      {
        System.out.println("enter 1 for general doctor \n2 for eye\n3 for ENT:");
        int decider2=s1.nextInt();
        if(decider2==1)
        {
          try
          {
            System.out.println("Doctor timing:Daily(10:00am - 12:00pm)");
            f = new File("general.txt");
            f.createNewFile();
            myWriter = new FileWriter("general.txt",true);
            int date=this.appoint_date();
            myWriter.write(String.valueOf(date)+","+String.valueOf(patient_id)+",");
            System.out.println("your appoint has been fixed sucessfully");
            myWriter.close();
          }
          catch(Exception e)
          {
            System.out.println("cannot write");
          }
        }
        else if(decider2==2)
        {
          try
          {
            System.out.println("Doctor timing:Daily(6:00pm - 9:00pm)");
            f = new File("eye.txt");
            f.createNewFile();
            myWriter = new FileWriter("eye.txt",true);
            int date=this.appoint_date();
            myWriter.write(String.valueOf(date)+","+String.valueOf(this.patient_id)+",");
            System.out.println("your appoint has been fixed sucessfully");
            myWriter.close();
          }
          catch(Exception e)
          {
            System.out.println("cannot write");
          }
        }
        if(decider2==3)
        {
          try
          {
            System.out.println("Doctor timing:Daily(2:00am - 4:00pm)");
            f = new File("ENT.txt");
            f.createNewFile();
            myWriter = new FileWriter("ENT.txt",true);
            int date=this.appoint_date();
            myWriter.write(String.valueOf(date)+","+String.valueOf(this.patient_id)+",");
            System.out.println("your appoint has been fixed sucessfully");
            myWriter.close();
          }
          catch(Exception e)
          {
            System.out.println("cannot write");
          }
        }
      }
      int appoint_date()
      {
        Calendar calendar = Calendar.getInstance();
        int cal=(calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("dates you can appoint:");
        for(int i=cal;i<=31;i++)
        {
            System.out.print(i+"  ");
        }
        System.out.println("\nDate you want to appoint:");
        int d=s1.nextInt();
        return d;
      }
      void recents(String filename)
      {
        try
        {
          BufferedReader input = new BufferedReader(new FileReader(filename));
          String last=null;
          String line;
          while ((line = input.readLine()) != null) 
          { 
            last = line;
          }
          System.out.println(last);
        }
        catch (Exception e)
        {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }
      }
}
