Package clinic contains patient class,doctor class,admin class.
In that directory - main class and package clinic.
As usual complie the main class in terminal and run it.
