#include <stdio.h>
#include <string.h>
#include <math.h>
#include "sqlite3.h"

int callback(void *NotUsed, int argc, char **argv, char **azColName) {
    NotUsed = 0;
    for (int i = 0; i < argc; i++) {
            printf("%15s\t",argv[i]);
        //printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;
}

typedef struct {
    char moviename[25];
    int success;
    int day_shows;
    int day_screen;
    int end_shows;
    int end_screen;
    int rem_day;
    int rem_end;
} already;

typedef struct {
    char moviename[25];
    int demand_score;
    int day_shows;
    int day_screen;
    int end_screen;
    int end_shows;
    int rem_day;
    int rem_end;
} new;

int main()
{
    sqlite3 *db;
    char *errMsg = 0;
    char sql[1000];

    int rec = sqlite3_open("ms.db",&db);

    if (rec != SQLITE_OK)
    {
        printf("Database cannot Opened: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);

        return 1;
    }


    strcpy(sql,"CREATE TABLE SCREEN_WEEK(S_No INT, Screen_Name TEXT, S1 TEXT, S2 TEXT, S3 TEXT)");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
    //printf("Error:%s",errMsg);s

    strcpy(sql,"CREATE TABLE SCHEDULE_DAY(S_No INT, Screen_Name TEXT, M1 TEXT, M2 TEXT, M3 TEXT)");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);

    strcpy(sql,"CREATE TABLE SCHEDULE_END(S_No INT, Screen_Name TEXT, M1 TEXT, M2 TEXT, M3 TEXT, M4 TEXT, M5 TEXT)");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);

    strcpy(sql,"CREATE TABLE SCREEN_WEEKEND(S_No INT, Screen_Name TEXT, S1 TEXT, S2 TEXT, S3 TEXT, S4 TEXT, S5 TEXT)");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
    //printf("Error:%s",errMsg);

    strcpy(sql,"CREATE TABLE ALREADY_RUNNING_MOVIES(S_No INT, Movie_Name TEXT, Success_Rate INT);");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
    //printf("Error:%s",errMsg);

    strcpy(sql,"CREATE TABLE NEW_MOVIES(S_No INT, Movie_Name TEXT, Actor TEXT, Actor_Rating INT, Actress TEXT, Actress_Rating INT, Director TEXT, Director_Rating INT, Music_Director TEXT, Music_Director_Rating INT, Trend_Score INT, Demand_Score FLOAT)");
    rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
    //printf("Error:%s",errMsg);

    int t;
    char screen_names[16][4][10],screen_names_ends[16][6][10];
    char sn[10],s1[10],s2[10],s3[10],sw1[10],sw2[10],sw3[10],sw4[10],sw5[10],sna[20];

    already old_movie[20];
    new new_movie[20];

    char name_screen[16][10]={"Bigpix","Elite","Rock","Main","Musical","Jazz","Blues","IMAX","Screen 1","Screen 2","Screen 3","Screen 4","Screen 5","Screen 6","Screen 7","Screen 8"};

    for (t=0; t<16; t++)
    {
        strcpy(screen_names[t][0],name_screen[t]);
        strcpy(screen_names_ends[t][0],name_screen[t]);
    }

    // Time slots for all 16 screens
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(1,'BigPix','7.30 am', '12.30 pm', '5.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(2,'Elite', '7.45 am', '12.45 pm', '5.45 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(3,'Rock', '7.55 am', '12.55 pm', '5.55 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(4,'Main', '8.00 am', '1.00 pm', '6.00 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(5,'Musical', '8.05 am', '1.05 pm', '6.05 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(6,'Jazz', '8.15 am', '1.15 pm', '6.15 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(7,'Blues', '8.20 am', '1.20 pm', '6.20 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(8,'IMAX', '8.30 am', '1.30 pm', '6.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(9,'Screen 1', '8.40 am', '1.40 pm', '6.40 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(10,'Screen 2','8.50 am', '1.50 pm', '6.50 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(11,'Screen 3', '9.00 am', '2.00 pm', '7.00 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(12,'Screen 4', '9.05 am', '2.05 pm', '7.05 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(13,'Screen 5', '9.15 am', '2.15 pm', '7.15 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(14,'Screen 6', '9.30 am', '2.30 pm', '7.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(15,'Screen 7', '10.30 am', '3.30 pm', '8.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES(16,'Screen 8', '11.30 am', '4.30 pm', '9.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);

    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (1,'BigPix', '7.00 am', '11.00 am', '2.30 pm', '6.30 pm', '10.00 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (2,'Elite', '6.45 am', '10.45 am', '2.15 pm', '6.15 pm', '9.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (3,'Rock', '6.30 am', '10.30 am', '2.00 pm', '6.00 pm', '9.20 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (4,'Main', '7.30 am', '10.30 am', '2.00 pm', '5.30 pm', '9.00 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (5,'Musical', '7.15 am', '10.15 am', '1.45 pm', '5.00 pm', '8.45 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (6,'Jazz', '7.10 am', '10.10 am', '1.40 pm', '4.50 pm', '8.35 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (7,'Blues', '7.20 am', '10.20 am', '1.35 pm', '4.55 pm', '8.40 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (8,'IMAX', '8.00 am', '12.00 am', '3.30 pm', '7.00 pm', '10.00 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (9,'Screen 1', '7.40 am', '10.40 am', '2.10 pm', '5.40 pm', '9.10 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (10,'Screen 2', '7.45 am', '10.45 am', '2.15 pm', '5.45 pm', '9.15 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (11,'Screen 3', '7.50 am', '10.50 am', '2.20 pm', '5.50 pm', '9.20 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (12,'Screen 4', '8.00 am', '11.15 am', '2.35 pm', '6.35 pm', '10.35 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (13,'Screen 5', '8.10 am', '11.20 am', '2.40 pm', '6.40 pm', '10.40 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (14,'Screen 6', '8.15 am', '11.30 am', '2.45 pm', '6.45 pm', '10.45 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (15,'Screen 7', '8.30 am', '12.00 pm', '4.00 pm', '8.00 pm', '11.30 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES (16,'Screen 8', '9.00 am', '12.35 pm', '4.05 pm', '8.10 pm', '11.45 pm')");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);

//In case the timings are provided by the user as input
/*
    for (int k=1 ;k<=2 ;k++)
    {

        printf("\nEnter the Screen Name:");
        gets(sn);
        printf("\nWeekdays Slot Timings");
        printf("\nEnter the timing for Slot-1:");
        gets(s1);
        printf("Enter the timing for Slot-2:");
        gets(s2);
        printf("Enter the timing for Slot-3:");
        gets(s3);
        sprintf(sql,"INSERT INTO SCREEN_WEEK VALUES('%s','%s','%s','%s')",sn,s1,s2,s3);
        rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
        //printf("Error:%s",errMsg);

        printf("Weekend Slot Timings");
        printf("\nEnter the timing for Slot-1:");
        gets(sw1);
        printf("Enter the timing for Slot-2:");
        gets(sw2);
        printf("Enter the timing for Slot-3:");
        gets(sw3);
        printf("Enter the timing for Slot-4:");
        gets(sw4);
        printf("Enter the timing for Slot-5:");
        gets(sw5);
        sprintf(sql,"INSERT INTO SCREEN_WEEKEND VALUES('%s','%s','%s','%s','%s','%s')",sn,sw1,sw2,sw3,sw4,sw5);
        //printf("%s\n",sql8);
        rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
        //printf("Error:%s",errMsg);
    }


    sqlite3_exec(db,"SELECT * FROM SCREEN_WEEK",callback,0,&errMsg);
    sqlite3_exec(db,"SELECT * FROM SCREEN_WEEKEND",callback,0,&errMsg);
    */

    int i,j,am,ub,nm,sp,ar,arr,dr,mdr,ts,ds;
    char amn[100],mn[100],a[100],ac[100],d[100],md[100];


    printf("Enter the number of already running movies:");
    scanf("%d",&am);
    printf("Enter the number of new movies:");
    scanf("%d",&nm);
    int c;
    while((c= getchar()) != '\n' && c != EOF);

    printf("Enter already running movie details:\n");

    for (i=0 ;i<am ;i++)
    {
        printf("Movie Name:");
        gets(amn);
        strcpy(old_movie[i].moviename,amn);
        printf("Seats unbooked for running movies - Movie %d : ",i+1);
        scanf("%d",&ub);
        printf("Total Seats:");
        scanf("%d",&ts);
        while((c= getchar()) != '\n' && c != EOF);

        sp=round(10*(ts-ub)/ts);
        old_movie[i].success=sp;
        sprintf(sql,"INSERT INTO ALREADY_RUNNING_MOVIES VALUES(%d,'%s',%d)",i+1,amn,sp);
        rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
        //printf("Error:%s",errMsg);
    }

    printf("Enter newly released movie details:\n");

    for (j=0 ;j<nm ; j++)
    {
        printf("\nMovie Name:");
        gets(mn);
        strcpy(new_movie[j].moviename,mn);

        printf("Actor:");
        gets(a);
        printf("Actor Rating (Scale of 20):");
        scanf("%d",&ar);
        while((c= getchar()) != '\n' && c != EOF);

        printf("Actress:");
        gets(ac);
        printf("Actress Rating (Scale of 20):");
        scanf("%d",&arr);
        while((c= getchar()) != '\n' && c != EOF);

        printf("Director:");
        gets(d);
        printf("Director Rating (Scale of 20):");
        scanf("%d",&dr);
        while((c= getchar()) != '\n' && c != EOF);

        printf("Music Director:");
        gets(md);
        printf("Music Director Rating (Scale of 20):");
        scanf("%d",&mdr);
        while((c= getchar()) != '\n' && c != EOF);

        printf("Trend score (Scale of 20):");
        scanf("%d",&ts);
        while((c= getchar()) != '\n' && c != EOF);

        ds=(ar+arr+dr+mdr+ts)/10;
        new_movie[j].demand_score=ds;
        sprintf(sql,"INSERT INTO NEW_MOVIES VALUES(%d,'%s','%s',%d,'%s',%d,'%s',%d,'%s',%d,%d,%d)",j+1,mn,a,ar,ac,arr,d,dr,md,mdr,ts,ds);
        rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    }

    sprintf(sql,"ALTER TABLE ALREADY_RUNNING_MOVIES ADD COLUMN WEEKDAY_SHOWS int");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"ALTER TABLE ALREADY_RUNNING_MOVIES ADD COLUMN WEEKEND_SHOWS int");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"ALTER TABLE NEW_MOVIES ADD COLUMN WEEKDAY_SHOWS int");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    sprintf(sql,"ALTER TABLE NEW_MOVIES ADD COLUMN WEEKEND_SHOWS int");
    rec = sqlite3_exec(db, sql, 0, 0, & errMsg);

    int p,s,tot_demand=0,tot_success=0,old_day_shows,old_end_shows,new_day_shows,new_end_shows,sc=0,x=0,y=1,tot_day_shows=48,tot_end_shows=80;
    int sh=0,sh_end=0;
    for (i=0; i<am; i++)
        tot_success+=old_movie[i].success;
    for (i=0; i<nm; i++)
        tot_demand+=new_movie[i].demand_score;
    old_day_shows=tot_success*48/(tot_success+tot_demand);
    old_end_shows=tot_success*80/(tot_success+tot_demand);
    new_day_shows=48-old_day_shows;
    new_end_shows=80-old_end_shows;


    for (i=0; i<am; i++)
    {

        old_movie[i].day_shows=(old_movie[i].success)*(old_day_shows)/(tot_success);
        old_movie[i].end_shows=(old_movie[i].success)*(old_end_shows)/(tot_success);
        sh+=old_movie[i].day_shows;
        sh_end+=old_movie[i].end_shows;
        old_movie[i].day_screen=old_movie[i].day_shows/3;
        old_movie[i].end_screen=old_movie[i].end_shows/5;
        old_movie[i].rem_day=old_movie[i].day_shows%3;
        old_movie[i].rem_end=old_movie[i].end_shows%5;
        sprintf(sql,"UPDATE ALREADY_RUNNING_MOVIES SET WEEKDAY_SHOWS=%d, WEEKEND_SHOWS=%d WHERE S_No=%d",old_movie[i].day_shows,old_movie[i].end_shows,i+1);
        rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    }
    for (i=0; i<nm-1; i++)
    {
        new_movie[i].day_shows=(new_movie[i].demand_score)*(new_day_shows)/(tot_demand);
        new_movie[i].end_shows=(new_movie[i].demand_score)*(new_end_shows)/(tot_demand);
        sh+=new_movie[i].day_shows;
        sh_end+=new_movie[i].end_shows;
        new_movie[i].day_screen=new_movie[i].day_shows/3;
        new_movie[i].end_screen=new_movie[i].end_shows/5;
        new_movie[i].rem_day=new_movie[i].day_shows%3;
        new_movie[i].rem_end=new_movie[i].end_shows%5;
        sprintf(sql,"UPDATE NEW_MOVIES SET WEEKDAY_SHOWS=%d, WEEKEND_SHOWS=%d WHERE S_No=%d",new_movie[i].day_shows,new_movie[i].end_shows,i+1);
        rec = sqlite3_exec(db, sql, 0, 0, & errMsg);
    }

    new_movie[nm-1].day_shows=48-sh;
    new_movie[nm-1].end_shows=80-sh_end;
    new_movie[nm-1].day_screen=new_movie[nm-1].day_shows/3;
    new_movie[nm-1].end_screen=new_movie[nm-1].end_shows/5;
    new_movie[nm-1].rem_day=new_movie[nm-1].day_shows%3;
    new_movie[nm-1].rem_end=new_movie[nm-1].end_shows%5;


    for (i=0; i<am; i++)
        for (s=0; s<old_movie[i].day_screen; s++)
        {
            strcpy(screen_names[sc][1],old_movie[i].moviename);
            strcpy(screen_names[sc][2],old_movie[i].moviename);
            strcpy(screen_names[sc][3],old_movie[i].moviename);
            tot_day_shows-=3;
            sc++;
        }

    for (i=0; i<nm; i++)
        for (s=0; s<new_movie[i].day_screen; s++)
        {
            strcpy(screen_names[sc][1],new_movie[i].moviename);
            strcpy(screen_names[sc][2],new_movie[i].moviename);
            strcpy(screen_names[sc][3],new_movie[i].moviename);
            tot_day_shows-=3;
            sc++;
        }
    while (tot_day_shows!=0)
    {
        for (i=0; i<am; i++)
        {
            for (p=0; p<old_movie[i].rem_day; p++)
            {
                if (x/3==1)
                {
                    x=x%3;
                    sc++;
                }
                if (y==4)
                {
                    y=y%3;
                }
                strcpy(screen_names[sc][y],old_movie[i].moviename);
                tot_day_shows--;
                x+=1;
                y+=1;
            }
        }
        for (j=0; j<nm; j++)
        {
            for (p=0; p<new_movie[j].rem_day; p++)
            {

                if (x/3==1)
                {
                    x=x%3;
                    sc++;
                }
                if (y==4)
                {
                    y=y%3;
                }
                strcpy(screen_names[sc][y],new_movie[j].moviename);
                tot_day_shows--;
                x+=1;
                y+=1;
            }
        }
    }

    sc=0,x=0,y=1;

    for (i=0; i<am; i++)
        for (s=0; s<old_movie[i].end_screen; s++)
        {
            strcpy(screen_names_ends[sc][1],old_movie[i].moviename);
            strcpy(screen_names_ends[sc][2],old_movie[i].moviename);
            strcpy(screen_names_ends[sc][3],old_movie[i].moviename);
            strcpy(screen_names_ends[sc][4],old_movie[i].moviename);
            strcpy(screen_names_ends[sc][5],old_movie[i].moviename);
            tot_end_shows-=5;
            sc++;
        }

    for (j=0; j<nm; j++)
        for (s=0; s<new_movie[j].end_screen; s++)
        {
            strcpy(screen_names_ends[sc][1],new_movie[j].moviename);
            strcpy(screen_names_ends[sc][2],new_movie[j].moviename);
            strcpy(screen_names_ends[sc][3],new_movie[j].moviename);
            strcpy(screen_names_ends[sc][4],new_movie[j].moviename);
            strcpy(screen_names_ends[sc][5],new_movie[j].moviename);
            tot_end_shows-=5;
            sc++;
        }

    while (tot_end_shows!=0)
    {
        for (i=0; i<am; i++)
        {
            for (p=0; p<old_movie[i].rem_end; p++)
            {
                if (x/5==1)
                {
                    x=x%5;
                    sc++;
                }
                if (y==6)
                    y=y%5;
                strcpy(screen_names_ends[sc][y],old_movie[i].moviename);
                tot_end_shows--;
                x+=1;
                y+=1;
            }
        }
        for (j=0; j<nm; j++)
        {
            for (p=0; p<new_movie[j].rem_end; p++)
            {
                if (x/5==1)
                {
                    x=x%5;
                    sc++;
                }
                if (y==6)
                    y=y%5;
                strcpy(screen_names_ends[sc][y],new_movie[j].moviename);
                tot_end_shows--;
                x+=1;
                y+=1;
            }
        }
    }
    printf("\n\n\n");
    for(i=0; i<16; i++)
    {
        sprintf(sql,"INSERT INTO SCHEDULE_DAY VALUES(%d,'%s','%s','%s','%s')",i+1,screen_names[i][0],screen_names[i][1],screen_names[i][2],screen_names[i][3]);
        rec = sqlite3_exec(db, sql, 0, 0, &errMsg);

        sprintf(sql,"INSERT INTO SCHEDULE_END VALUES(%d,'%s','%s','%s','%s','%s','%s')",i+1,screen_names_ends[i][0],screen_names_ends[i][1],screen_names_ends[i][2],screen_names_ends[i][3],screen_names_ends[i][4],screen_names_ends[i][5]);
        rec = sqlite3_exec(db, sql, 0, 0, &errMsg);
    }
    printf("       Screen Name  Slot1/Movie 1   Slot2/Movie 2   Slot3/Movie 3\n");
    for (i=0; i<16; i++)
    {
        sprintf(sql,"SELECT Screen_Name, S1, S2, S3 FROM SCREEN_WEEK WHERE S_No=%d",i+1);
        rec = sqlite3_exec(db, sql, callback, 0, & errMsg);
        sprintf(sql,"SELECT Screen_Name, M1, M2, M3 FROM SCHEDULE_DAY WHERE S_No=%d",i+1);
        rec = sqlite3_exec(db, sql, callback, 0, & errMsg);
        printf("\n\n");
    }
    printf("       Screen Name    Slot1/Movie 1 Slot2/Movie 2  Slot3/Movie 3    Slot4/Movie 4     Slot5/Movie 5\n");
    for (i=0; i<16; i++)
    {
        sprintf(sql,"SELECT Screen_Name, S1, S2, S3, S4, S5 FROM SCREEN_WEEKEND WHERE S_No=%d",i+1);
        rec = sqlite3_exec(db, sql, callback, 0, & errMsg);
        sprintf(sql,"SELECT Screen_Name, M1, M2, M3, M4, M5 FROM SCHEDULE_END WHERE S_No=%d",i+1);
        rec = sqlite3_exec(db, sql, callback, 0, & errMsg);
        printf("\n\n");
    }


    sqlite3_close(db);
    return 0;
}

