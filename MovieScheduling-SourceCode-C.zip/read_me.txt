Team Members:
Subramanian T (3122 21 5001 110)
Sudharsan K (3122 21 5001 111)
Sundaresan V (3122 21 5001 112)

Some basic pointers regarding how to compile the program:

* As we've based use of sqlite3 database in the source code make sure you've imported the sqlite3.h header file properly
* Should also make sure it is compiled with sqlite3.c file which contains all the commands 
For example when you execute the program in the cmd
gcc Source_Code_Final.c sqlite3.c -o a
Then execute a
* Make sure you've deleted the created database every time you execute the program

After executing, the program will request the user for inputs regarding the movies, once provided the program will 
return the schedule for the screens on weekdays and weekends separately.

The output will be generated in the same terminal where the contents of the database will be displayed.